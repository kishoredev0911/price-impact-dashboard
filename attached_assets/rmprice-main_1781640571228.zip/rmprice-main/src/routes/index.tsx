import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState } from "react";
import {
  ALLOYS, QUARTERS, calcAll, cc, computeHistory, deriveSeries,
  derivedScrapWt, findInconsistencies, inconsistentIds, isManualAsCast,
  type Part, type RmIndex,
} from "@/lib/pricing";
import {
  downloadCalcExport, downloadHistoryExport, downloadPartsExport, downloadPartsTemplate,
  downloadRmTemplate, parsePartsExcel, parseRmExcel, downloadDerivationByVendorExport,
} from "@/lib/excel";
import { SEED_PARTS, SEED_RM_INDEX } from "@/lib/seed-data";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Trash2, Download, Upload, Plus, Calculator, Factory, FileSpreadsheet, History, AlertTriangle,
} from "lucide-react";
import { LayoutDashboard, GitBranch } from "lucide-react";
import { DashboardTab } from "@/components/dashboard-tab";
import { GrnTab } from "@/components/grn-tab";
import { PackageCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "RM Price Calculator — Aluminium Casting" },
      { name: "description", content: "Bulk quarterly price calculator with Excel I/O, price history and amendment tracking for aluminium casting parts." },
    ],
  }),
  component: Index,
});

const RM_ROWS = [...ALLOYS, "SCRAP"];

function Index() {
  const [rm, setRm] = useState<RmIndex>(() => {
    const init: RmIndex = {};
    for (const a of RM_ROWS) init[a] = { ...(SEED_RM_INDEX[a] ?? {}) };
    return init;
  });
  const [parts, setParts] = useState<Part[]>(SEED_PARTS);
  const [prevQ, setPrevQ] = useState<string>("Q4'25");
  const [newQ, setNewQ] = useState<string>("Q1'26");

  // Amendment header
  const [amendmentReason, setAmendmentReason] = useState("");

  // GRN qty keyed by part.id
  const [grnQty, setGrnQty] = useState<Record<string, number>>({});

  const rows = useMemo(() => calcAll(parts, rm, prevQ, newQ), [parts, rm, prevQ, newQ]);
  const history = useMemo(() => {
    const out: Record<string, Record<string, number | null>> = {};
    for (const p of parts) out[p.id] = computeHistory(p, rm);
    return out;
  }, [parts, rm]);
  const inconsistencies = useMemo(() => findInconsistencies(parts), [parts]);
  const badIds = useMemo(() => inconsistentIds(parts), [parts]);

  const totals = useMemo(() => {
    let oldSum = 0, newSum = 0, impactSum = 0;
    for (const r of rows) {
      oldSum += r.part.basePrice;
      if (r.newPrice != null) { newSum += r.newPrice; impactSum += r.newPrice - r.part.basePrice; }
    }
    return { oldSum, newSum, impactSum };
  }, [rows]);

  function updateRm(alloy: string, q: string, v: string) {
    setRm((prev) => ({ ...prev, [alloy]: { ...prev[alloy], [q]: v === "" ? null : Number(v) } }));
  }
  function updatePart(id: string, patch: Partial<Part>) {
    setParts((prev) => prev.map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }
  function addPart() {
    setParts((p) => [...p, {
      id: `p${Date.now()}`, partNumber: "", description: "", plant: "1020",
      vendorCode: "", alloy: "SCM 14", castWt: 0, machiningWt: 0, asCast: false,
      basePrice: 0, baseQuarter: prevQ, poNum: "",
    }]);
  }
  function removePart(id: string) { setParts((p) => p.filter((x) => x.id !== id)); }

  function downloadCalc() {
    downloadCalcExport(parts, rows, rm, prevQ, newQ, { amendmentReason });
  }

  async function handlePartsUpload(file: File, mode: "append" | "replace") {
    const incoming = await parsePartsExcel(file, prevQ);
    setParts((prev) => (mode === "replace" ? incoming : [...prev, ...incoming]));
  }
  async function handleRmUpload(file: File) {
    const incoming = await parseRmExcel(file);
    setRm((prev) => {
      const merged: RmIndex = { ...prev };
      for (const alloy of Object.keys(incoming)) {
        merged[alloy] = { ...(merged[alloy] ?? {}), ...incoming[alloy] };
      }
      return merged;
    });
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b bg-card">
        <div className="mx-auto max-w-[1700px] px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="rounded-md bg-primary text-primary-foreground p-2"><Factory className="size-5" /></div>
            <div>
              <h1 className="text-xl font-semibold tracking-tight">RM Price Calculator</h1>
              <p className="text-xs text-muted-foreground">Aluminium casting · Bulk quarterly recompute · Excel I/O</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{parts.length} parts</Badge>
            <Badge variant="secondary">{RM_ROWS.length} alloys</Badge>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1700px] px-6 py-6 space-y-6">
        {/* Amendment header */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Amendment Header</CardTitle>
            <CardDescription>Captured on every export.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-1.5"><Label>Amendment Reason</Label>
              <Input value={amendmentReason} onChange={(e) => setAmendmentReason(e.target.value)} placeholder="e.g. Q1'26 RM revision" /></div>
          </CardContent>
        </Card>

        {/* Quarter selector */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Quarter Comparison</CardTitle>
            <CardDescription>Pick the base & target quarter — everything recomputes instantly.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-1.5"><Label>Previous Quarter</Label>
              <Select value={prevQ} onValueChange={setPrevQ}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{QUARTERS.map((q) => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>New Quarter</Label>
              <Select value={newQ} onValueChange={setNewQ}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{QUARTERS.map((q) => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <Stat label={`Previous Qtr Impact (${prevQ})`} value={`₹${totals.oldSum.toFixed(2)}`} />
            <Stat label={`New Price Impact (${newQ})`} value={`₹${totals.newSum.toFixed(2)}`} delta={totals.impactSum} />
          </CardContent>
        </Card>

        {inconsistencies.length > 0 && (
          <Card className="border-red-300 bg-red-50">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-red-700 flex items-center gap-2">
                <AlertTriangle className="size-4" /> Inconsistent Part Master ({inconsistencies.length} issue{inconsistencies.length>1?"s":""})
              </CardTitle>
              <CardDescription>Same Part # must use the same Alloy, Cast Wt and Machining Wt across plants / POs / vendors.</CardDescription>
            </CardHeader>
            <CardContent className="text-xs space-y-1">
              {inconsistencies.slice(0,8).map((inc, i) => (
                <div key={i}>
                  <span className="font-mono font-semibold">{inc.partNumber}</span>{" "}
                  <span className="text-muted-foreground">{inc.field}</span> →{" "}
                  {inc.values.map((v, j) => (
                    <span key={j} className="mr-2">
                      <b>{String(v.value)}</b> <span className="text-muted-foreground">({v.ids.length}x)</span>
                    </span>
                  ))}
                </div>
              ))}
              {inconsistencies.length > 8 && <div className="text-muted-foreground">…and {inconsistencies.length - 8} more.</div>}
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="dashboard">
          <TabsList>
            <TabsTrigger value="dashboard"><LayoutDashboard className="size-4 mr-1.5" />Dashboard</TabsTrigger>
            <TabsTrigger value="results"><Calculator className="size-4 mr-1.5" />Calculated Prices</TabsTrigger>
            <TabsTrigger value="deriv"><GitBranch className="size-4 mr-1.5" />Price Derivation</TabsTrigger>
            <TabsTrigger value="history"><History className="size-4 mr-1.5" />Price History</TabsTrigger>
            <TabsTrigger value="grn"><PackageCheck className="size-4 mr-1.5" />GRN Impact</TabsTrigger>
            <TabsTrigger value="parts">Part Master ({parts.length})</TabsTrigger>
            <TabsTrigger value="rm">RM Index</TabsTrigger>
          </TabsList>

          {/* ============ DASHBOARD ============ */}
          <TabsContent value="dashboard" className="mt-4">
            <DashboardTab parts={parts} rm={rm} rows={rows} prevQ={prevQ} newQ={newQ} />
          </TabsContent>

          {/* ============ RESULTS ============ */}
          <TabsContent value="results" className="mt-4">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">Calculated Prices — {prevQ} → {newQ}</CardTitle>
                  <CardDescription>New Price = Old Price + RM Impact − Scrap Deduction. Scrap Deduction = (Prev Scrap / SCM14 Prev) × (Scrap Wt × 80%) and is <b>always subtracted</b>.</CardDescription>
                </div>
                <Button onClick={downloadCalc} size="sm"><Download className="size-4 mr-1.5" />Export Excel</Button>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead className="bg-muted text-muted-foreground sticky top-0">
                    <tr className="text-left">
                      <Th>CC</Th><Th>Plant</Th><Th>PO Num</Th><Th>Vendor</Th>
                      <Th>Part #</Th><Th>Description</Th><Th>Alloy</Th>
                      <Th right>Cast Wt</Th><Th right>Mach Wt</Th><Th right>Eff Scrap</Th>
                      <Th right>Prev Base</Th><Th right>New Base</Th>
                      <Th right>Melt Loss</Th>
                      <Th right>Prev Scrap</Th><Th right>SCM14 Prev</Th>
                      <Th right>RM Impact</Th><Th right>Scrap Ded</Th>
                      <Th right>Old Price</Th><Th right>New Price</Th><Th right>Δ%</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r) => {
                      const old = r.oldPrice ?? null;
                      const pct = r.newPrice != null && old
                        ? ((r.newPrice - old) / old) * 100 : null;
                      return (
                        <tr key={r.part.id} className="border-t hover:bg-muted/40">
                          <Td className="font-mono">{cc(r.part)}</Td>
                          <Td className="font-mono">{r.part.plant}</Td>
                          <Td className="font-mono">{r.part.poNum ?? ""}</Td>
                          <Td className="font-mono">{r.part.vendorCode ?? ""}</Td>
                          <Td className="font-mono">{r.part.partNumber}</Td>
                          <Td><div className="max-w-[200px] truncate">{r.part.description}</div>
                            {r.note && <div className="text-[10px] text-destructive">{r.note}</div>}</Td>
                          <Td><Badge variant="outline" className="text-[10px]">{r.part.alloy}</Badge></Td>
                          <Td right>{r.part.castWt.toFixed(3)}</Td>
                          <Td right>{r.part.machiningWt.toFixed(3)}</Td>
                          <Td right>{r.effectiveScrapWt.toFixed(3)}</Td>
                          <Td right>{fmt(r.prevBase)}</Td><Td right>{fmt(r.newBase)}</Td>
                          <Td right>{r.meltingLoss.toFixed(3)}</Td>
                          <Td right>{fmt(r.prevScrap)}</Td><Td right>{fmt(r.scm14Prev)}</Td>
                          <Td right className={signColor(r.rmImpact)}>{fmt(r.rmImpact)}</Td>
                          <Td right>{fmt(r.scrapDeduction)}</Td>
                          <Td right>{old != null ? `₹${old.toFixed(2)}` : "—"}</Td>
                          <Td right className="font-semibold">{r.newPrice != null ? `₹${r.newPrice.toFixed(2)}` : "—"}</Td>
                          <Td right className={signColor(pct)}>{pct != null ? `${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%` : "—"}</Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ============ PRICE DERIVATION ============ */}
          <TabsContent value="deriv" className="mt-4">
            <DerivationTab parts={parts} rm={rm} grnQty={grnQty} />
          </TabsContent>

          {/* ============ PRICE HISTORY ============ */}
          <TabsContent value="history" className="mt-4">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">Price History — all parts × all quarters</CardTitle>
                  <CardDescription>Chain-computed from each part's base quarter using the RM Index.</CardDescription>
                </div>
                <Button size="sm" onClick={() => downloadHistoryExport(parts, history)}>
                  <Download className="size-4 mr-1.5" />Export Excel
                </Button>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <table className="text-xs border-collapse">
                  <thead className="bg-muted text-muted-foreground">
                    <tr>
                      <Th>CC</Th><Th>Part #</Th><Th>Description</Th><Th>Alloy</Th>
                      {QUARTERS.map((q) => (
                        <Th key={q} right>
                          <span className={q === prevQ ? "text-primary font-semibold" : q === newQ ? "text-accent font-semibold" : ""}>{q}</span>
                        </Th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {parts.map((p) => (
                      <tr key={p.id} className="border-t">
                        <Td className="font-mono whitespace-nowrap">{cc(p)}</Td>
                        <Td className="font-mono whitespace-nowrap">{p.partNumber}</Td>
                        <Td><div className="max-w-[180px] truncate">{p.description}</div></Td>
                        <Td><Badge variant="outline" className="text-[10px]">{p.alloy}</Badge></Td>
                        {QUARTERS.map((q) => {
                          const v = history[p.id]?.[q];
                          const isBase = q === p.baseQuarter;
                          return (
                            <Td key={q} right className={`tabular-nums ${isBase ? "font-semibold underline" : ""}`}>
                              {v != null ? v.toFixed(2) : "—"}
                            </Td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ============ GRN IMPACT ============ */}
          <TabsContent value="grn" className="mt-4">
            <GrnTab parts={parts} rows={rows} grnQty={grnQty} setGrnQty={setGrnQty}
              prevQ={prevQ} newQ={newQ} />
          </TabsContent>

          {/* ============ PART MASTER ============ */}
          <TabsContent value="parts" className="mt-4">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">Part Master</CardTitle>
                  <CardDescription>
                    Parts ending in <b>0</b> or <b>6</b> are forced AS CAST. Other parts manually flagged AS CAST are <span className="text-amber-700 font-semibold">highlighted amber</span>.
                  </CardDescription>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <Button size="sm" variant="outline" onClick={downloadPartsTemplate}>
                    <FileSpreadsheet className="size-4 mr-1.5" />Template
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => downloadPartsExport(parts)}>
                    <Download className="size-4 mr-1.5" />Export
                  </Button>
                  <UploadButton label="Bulk Upload" accept=".xlsx,.xls"
                    onFile={(f) => handlePartsUpload(f, "append")} />
                  <UploadButton label="Replace All" variant="destructive" accept=".xlsx,.xls"
                    onFile={(f) => handlePartsUpload(f, "replace")} />
                  <PasteDialog onPaste={(rows) => setParts((p) => [...p, ...rows])} defaultQuarter={prevQ} />
                  <Button onClick={addPart} size="sm"><Plus className="size-4 mr-1.5" />Add</Button>
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <table className="w-full text-xs border-collapse">
                  <thead className="bg-muted text-muted-foreground">
                    <tr className="text-left">
                      <Th>CC</Th><Th>Part #</Th><Th>Description</Th><Th>Plant</Th><Th>Vendor</Th><Th>PO Num</Th><Th>Alloy</Th>
                      <Th right>Cast Wt</Th><Th right>Mach Wt</Th><Th right>Scrap Wt</Th>
                      <Th>AS CAST</Th><Th right>SAP Price</Th><Th>Base Q</Th><Th></Th>
                    </tr>
                  </thead>
                  <tbody>
                    {parts.map((p) => {
                      const manual = isManualAsCast(p);
                      const auto06 = /[06]$/.test(p.partNumber);
                      const bad = badIds.has(p.id);
                      return (
                        <tr key={p.id} className={`border-t ${bad ? "bg-red-100/70" : manual ? "bg-amber-100/70" : ""}`}>
                          <Td className="font-mono whitespace-nowrap">{cc(p)}</Td>
                          <Td><Input className="h-8 font-mono" value={p.partNumber} onChange={(e) => updatePart(p.id, { partNumber: e.target.value })} /></Td>
                          <Td><Input className="h-8" value={p.description} onChange={(e) => updatePart(p.id, { description: e.target.value })} /></Td>
                          <Td><Input className="h-8 w-20" value={p.plant} onChange={(e) => updatePart(p.id, { plant: e.target.value })} /></Td>
                          <Td><Input className="h-8 w-24" value={p.vendorCode ?? ""} onChange={(e) => updatePart(p.id, { vendorCode: e.target.value })} /></Td>
                          <Td><Input className="h-8 w-24" value={p.poNum ?? ""} onChange={(e) => updatePart(p.id, { poNum: e.target.value })} /></Td>
                          <Td>
                            <Select value={p.alloy} onValueChange={(v) => updatePart(p.id, { alloy: v })}>
                              <SelectTrigger className="h-8 w-28"><SelectValue /></SelectTrigger>
                              <SelectContent>{ALLOYS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
                            </Select>
                          </Td>
                          <Td right><Input className="h-8 w-20 text-right" type="number" step="0.001" value={p.castWt} onChange={(e) => updatePart(p.id, { castWt: Number(e.target.value) })} /></Td>
                          <Td right><Input className="h-8 w-20 text-right" type="number" step="0.001" value={p.machiningWt} onChange={(e) => updatePart(p.id, { machiningWt: Number(e.target.value) })} /></Td>
                          <Td right className="tabular-nums text-muted-foreground">{derivedScrapWt(p).toFixed(3)}</Td>
                          <Td>
                            <div className="flex items-center gap-1.5">
                              <Checkbox
                                checked={auto06 ? true : p.asCast}
                                disabled={auto06}
                                onCheckedChange={(c) => updatePart(p.id, { asCast: !!c })}
                              />
                              {auto06 && <Badge variant="secondary" className="text-[9px]">auto (0/6)</Badge>}
                              {manual && <AlertTriangle className="size-3.5 text-amber-700" aria-label="manual AS CAST" />}
                            </div>
                          </Td>
                          <Td right><Input className="h-8 w-24 text-right" type="number" step="0.01" value={p.basePrice} onChange={(e) => updatePart(p.id, { basePrice: Number(e.target.value) })} /></Td>
                          <Td>
                            <Select value={p.baseQuarter} onValueChange={(v) => updatePart(p.id, { baseQuarter: v })}>
                              <SelectTrigger className="h-8 w-24"><SelectValue /></SelectTrigger>
                              <SelectContent>{QUARTERS.map((q) => <SelectItem key={q} value={q}>{q}</SelectItem>)}</SelectContent>
                            </Select>
                          </Td>
                          <Td>
                            <Button size="icon" variant="ghost" onClick={() => removePart(p.id)}>
                              <Trash2 className="size-4 text-destructive" />
                            </Button>
                          </Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* ============ RM INDEX ============ */}
          <TabsContent value="rm" className="mt-4">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0">
                <div>
                  <CardTitle className="text-base">RM Price Index</CardTitle>
                  <CardDescription>Single source of truth — bulk upload via Excel template.</CardDescription>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <Button size="sm" variant="outline" onClick={() => downloadRmTemplate()}>
                    <FileSpreadsheet className="size-4 mr-1.5" />Empty Template
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => downloadRmTemplate(rm)}>
                    <Download className="size-4 mr-1.5" />Export Current
                  </Button>
                  <UploadButton label="Bulk Upload" accept=".xlsx,.xls" onFile={handleRmUpload} />
                </div>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <table className="text-xs border-collapse">
                  <thead>
                    <tr className="bg-muted text-muted-foreground">
                      <th className="px-2 py-2 text-left border sticky left-0 bg-muted z-10 min-w-[120px]">Alloy / Grade</th>
                      {QUARTERS.map((q) => (
                        <th key={q} className="px-2 py-2 text-center border min-w-[88px]">
                          <span className={q === prevQ ? "text-primary font-semibold" : q === newQ ? "text-accent font-semibold" : ""}>{q}</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {RM_ROWS.map((alloy) => (
                      <tr key={alloy} className="border-t">
                        <td className="px-2 py-1 font-medium whitespace-nowrap border sticky left-0 bg-card z-10">{alloy}</td>
                        {QUARTERS.map((q) => (
                          <td key={q} className="border p-0.5">
                            <Input
                              className="h-7 w-full text-right text-xs px-1.5 border-0 rounded-none"
                              type="number" step="0.01"
                              value={rm[alloy]?.[q] ?? ""}
                              onChange={(e) => updateRm(alloy, q, e.target.value)}
                            />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function fmt(n: number | null | undefined) { return n == null ? "—" : n.toFixed(2); }
function signColor(n: number | null | undefined) {
  if (n == null || n === 0) return "";
  return n > 0 ? "text-emerald-600" : "text-red-600";
}
function Th({ children, right }: { children?: React.ReactNode; right?: boolean }) {
  return <th className={`px-2 py-2 font-medium ${right ? "text-right" : "text-left"} whitespace-nowrap`}>{children}</th>;
}
function Td({ children, right, className = "" }: { children?: React.ReactNode; right?: boolean; className?: string }) {
  return <td className={`px-2 py-1.5 align-middle ${right ? "text-right tabular-nums" : ""} ${className}`}>{children}</td>;
}

function Stat({ label, value, delta }: { label: string; value: string; delta?: number }) {
  return (
    <div className="rounded-md border bg-muted/30 p-3">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold tabular-nums">{value}</div>
      {delta != null && (
        <div className={`text-xs tabular-nums ${delta >= 0 ? "text-emerald-600" : "text-red-600"}`}>
          {delta >= 0 ? "+" : ""}₹{delta.toFixed(2)} impact
        </div>
      )}
    </div>
  );
}

function UploadButton({
  label, onFile, accept, variant = "outline",
}: { label: string; onFile: (f: File) => void | Promise<void>; accept: string; variant?: "outline" | "destructive" }) {
  const ref = useRef<HTMLInputElement>(null);
  return (
    <>
      <Button size="sm" variant={variant} onClick={() => ref.current?.click()}>
        <Upload className="size-4 mr-1.5" />{label}
      </Button>
      <input ref={ref} type="file" accept={accept} className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
          if (ref.current) ref.current.value = "";
        }} />
    </>
  );
}

function PasteDialog({
  onPaste, defaultQuarter,
}: { onPaste: (rows: Part[]) => void; defaultQuarter: string }) {
  const [text, setText] = useState("");
  const [open, setOpen] = useState(false);
  function commit() {
    const lines = text.trim().split(/\r?\n/).filter(Boolean);
    const out: Part[] = [];
    for (const line of lines) {
      const cells = line.includes("\t") ? line.split("\t") : line.split(",");
      if (cells.length < 6) continue;
      const partNumber = cells[0].trim();
      const userAsCast = /^(y|yes|true|1)$/i.test(cells[7]?.trim() ?? "");
      const castWt = Number(cells[5]) || 0;
      const machWt = Number(cells[6]) || 0;
      out.push({
        id: `p${Date.now()}-${out.length}`,
        partNumber,
        description: cells[1]?.trim() ?? "",
        plant: cells[2]?.trim() ?? "1020",
        vendorCode: cells[3]?.trim() ?? "",
        alloy: cells[4]?.trim() ?? "SCM 14",
        castWt,
        machiningWt: machWt,
        asCast: /[06]$/.test(partNumber) ? true : userAsCast,
        basePrice: Number(cells[8]) || 0,
        baseQuarter: defaultQuarter,
        poNum: cells[9]?.trim() ?? "",
      });
    }
    if (out.length) onPaste(out);
    setText(""); setOpen(false);
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm" variant="outline">Paste</Button></DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Bulk paste parts</DialogTitle>
          <DialogDescription>
            CSV or TSV — one row per line:
            <code className="block mt-1 text-xs bg-muted p-2 rounded">PartNo, Description, Plant, VendorCode, Alloy, CastWt, MachWt, AsCast(Y/N), BasePrice, PoNum</code>
          </DialogDescription>
        </DialogHeader>
        <Textarea rows={10} value={text} onChange={(e) => setText(e.target.value)} />
        <Button onClick={commit}>Add rows</Button>
      </DialogContent>
    </Dialog>
  );
}

function DerivationTab({ parts, rm, grnQty }: { parts: Part[]; rm: RmIndex; grnQty: Record<string, number> }) {
  const [pid, setPid] = useState<string>(parts[0]?.id ?? "");
  const p = parts.find((x) => x.id === pid) ?? parts[0];
  const steps = useMemo(() => (p ? deriveSeries(p, rm) : []), [p, rm]);
  if (!p) return <Card><CardContent className="py-8 text-center text-muted-foreground">No parts.</CardContent></Card>;
  return (
    <Card>
      <CardHeader className="pb-3 flex flex-row items-center justify-between space-y-0 gap-4 flex-wrap">
        <div className="min-w-[260px]">
          <CardTitle className="text-base">Price Derivation</CardTitle>
          <CardDescription>Step-by-step from <b>{p.baseQuarter}</b> (SAP ₹{p.basePrice.toFixed(2)}) forward, stops where RM index ends.</CardDescription>
        </div>
        <div className="flex gap-2 flex-wrap items-center">
          <Button size="sm" onClick={() => downloadDerivationByVendorExport(parts, rm, grnQty)}>
            <Download className="size-4 mr-1.5" />Export Vendor-wise (all vendors)
          </Button>
          <Select value={pid} onValueChange={setPid}>
            <SelectTrigger className="w-[360px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              {parts.map((x) => (
                <SelectItem key={x.id} value={x.id}>
                  {x.partNumber} · {x.plant} · {x.alloy} — {x.description.slice(0, 40)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <Th>From → To</Th>
              <Th right>Old Price</Th>
              <Th right>Prev RM</Th><Th right>New RM</Th>
              <Th right>Melt Loss</Th>
              <Th right>RM Impact</Th>
              <Th right>Scrap Wt</Th><Th right>Prev Scrap</Th><Th right>SCM14 Prev</Th>
              <Th right>Scrap Ded</Th>
              <Th right>New Price</Th><Th>Formula</Th>
            </tr>
          </thead>
          <tbody>
            {steps.map((s, i) => (
              <tr key={i} className="border-t hover:bg-muted/40">
                <Td className="font-mono whitespace-nowrap">{s.fromQ} → {s.toQ}</Td>
                <Td right>₹{s.oldPrice.toFixed(2)}</Td>
                <Td right>{fmt(s.prevBase)}</Td><Td right>{fmt(s.newBase)}</Td>
                <Td right>{s.meltingLoss.toFixed(3)}</Td>
                <Td right className={signColor(s.rmImpact)}>{fmt(s.rmImpact)}</Td>
                <Td right>{s.scrapWt.toFixed(3)}</Td>
                <Td right>{fmt(s.prevScrap)}</Td><Td right>{fmt(s.scm14Prev)}</Td>
                <Td right>{s.scrapDeduction.toFixed(2)}</Td>
                <Td right className="font-semibold">{s.newPrice != null ? `₹${s.newPrice.toFixed(2)}` : "—"}</Td>
                <Td className="text-[10px] text-muted-foreground whitespace-nowrap">
                  {s.newPrice != null
                    ? `${s.oldPrice.toFixed(2)} + ${(s.rmImpact ?? 0).toFixed(2)} − ${s.scrapDeduction.toFixed(2)}`
                    : (s.note ?? "—")}
                </Td>
              </tr>
            ))}
            {steps.length === 0 && (
              <tr><Td className="text-muted-foreground py-6 text-center">No derivation possible — base quarter not in series.</Td></tr>
            )}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
