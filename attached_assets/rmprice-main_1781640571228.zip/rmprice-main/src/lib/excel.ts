import * as XLSX from "xlsx";
import ExcelJS from "exceljs";
import {
  ALLOYS, QUARTERS, cc, deriveSeries, derivedScrapWt,
  type CalcRow, type Part, type RmIndex, endsIn0or6,
} from "./pricing";

const RM_ROWS = [...ALLOYS, "SCRAP"];

/* ---------------- VENDOR GROUPING HELPERS ---------------- */

const VENDOR_FALLBACK = "_NoVendor";
function vKey(v?: string) { return (v ?? "").trim() || VENDOR_FALLBACK; }
function sanitizeSheet(name: string) {
  // Excel sheet names: ≤31 chars, no : \ / ? * [ ]
  return name.replace(/[:\\/?*[\]]/g, "_").slice(0, 31) || "Sheet";
}
function groupByVendor<T extends { vendorCode?: string }>(items: T[]) {
  const map = new Map<string, T[]>();
  for (const it of items) {
    const k = vKey(it.vendorCode);
    const arr = map.get(k) ?? []; arr.push(it); map.set(k, arr);
  }
  return [...map.entries()].sort(([a],[b]) => a.localeCompare(b));
}
function sortKey(p: Pick<Part,"poNum"|"plant"|"partNumber">) {
  return `${p.poNum ?? ""}|${p.plant ?? ""}|${p.partNumber ?? ""}`;
}

function saveBlob(filename: string, data: unknown) {
  let ab: ArrayBuffer;
  if (data instanceof ArrayBuffer) ab = data;
  else if (ArrayBuffer.isView(data)) {
    const v = data as ArrayBufferView;
    ab = v.buffer.slice(v.byteOffset, v.byteOffset + v.byteLength) as ArrayBuffer;
  } else throw new Error("saveBlob: unsupported data type");
  const blob = new Blob([ab], { type: "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* ---------------- PARTS ---------------- */

export const PART_HEADERS = [
  "PartNo","Description","Plant","VendorCode","PoNum","Alloy",
  "CastWt","MachiningWt","AsCast(Y/N)","BasePrice","BaseQuarter",
] as const;

export function downloadPartsTemplate() {
  const ws = XLSX.utils.aoa_to_sheet([
    [...PART_HEADERS],
    ["100275560","FLANGE (CASTING)","1030","V10234","PO4567","SCM 14",0.96,0.96,"Y",243.81,"Q4'25"],
  ]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Parts");
  saveBlob("parts-template.xlsx", XLSX.write(wb, { type: "array", bookType: "xlsx" }));
}

export function downloadPartsExport(parts: Part[]) {
  const wb = XLSX.utils.book_new();
  // All parts sheet
  const all = parts
    .slice()
    .sort((a,b) => (vKey(a.vendorCode)).localeCompare(vKey(b.vendorCode)) || sortKey(a).localeCompare(sortKey(b)));
  const allRows = all.map((p) => [
    p.partNumber, p.description, p.plant, p.vendorCode ?? "", p.poNum ?? "", p.alloy,
    p.castWt, p.machiningWt, p.asCast ? "Y" : "N", p.basePrice, p.baseQuarter,
  ]);
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([[...PART_HEADERS], ...allRows]), "All Parts");
  // Per-vendor sheets
  for (const [vendor, items] of groupByVendor(parts)) {
    const sorted = items.slice().sort((a,b)=> sortKey(a).localeCompare(sortKey(b)));
    const rows = sorted.map((p) => [
      p.partNumber, p.description, p.plant, p.vendorCode ?? "", p.poNum ?? "", p.alloy,
      p.castWt, p.machiningWt, p.asCast ? "Y" : "N", p.basePrice, p.baseQuarter,
    ]);
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([[...PART_HEADERS], ...rows]),
      sanitizeSheet(`V_${vendor}`));
  }
  saveBlob("parts.xlsx", XLSX.write(wb, { type: "array", bookType: "xlsx" }));
}

export async function parsePartsExcel(file: File, defaultQuarter: string): Promise<Part[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
  const out: Part[] = [];
  for (const r of rows) {
    const partNumber = String(r["PartNo"] ?? r["Part Number"] ?? "").trim();
    if (!partNumber) continue;
    const userAsCast = /^(y|yes|true|1)$/i.test(
      String(r["AsCast(Y/N)"] ?? r["AsCast"] ?? r["AS CAST"] ?? "").trim()
    );
    const castWt = Number(r["CastWt"] ?? r["Cast Wt"] ?? 0) || 0;
    let mach = Number(r["MachiningWt"] ?? r["Mach Wt"] ?? r["Machining Wt"] ?? NaN);
    if (Number.isNaN(mach)) {
      // legacy: ScrapWt provided → machining = cast - scrap
      const sw = Number(r["ScrapWt"] ?? r["Scrap Wt"] ?? 0) || 0;
      mach = Math.max(castWt - sw, 0);
    }
    out.push({
      id: `p${Date.now()}-${out.length}-${Math.random().toString(36).slice(2, 6)}`,
      partNumber,
      description: String(r["Description"] ?? ""),
      plant: String(r["Plant"] ?? "1020"),
      vendorCode: String(r["VendorCode"] ?? r["Vendor Code"] ?? "").trim(),
      alloy: String(r["Alloy"] ?? "SCM 14"),
      castWt,
      machiningWt: +mach.toFixed(4),
      asCast: endsIn0or6(partNumber) ? true : userAsCast,
      basePrice: Number(r["BasePrice"] ?? r["Base Price"] ?? 0) || 0,
      baseQuarter: String(r["BaseQuarter"] ?? r["Base Quarter"] ?? defaultQuarter),
      poNum: String(r["PoNum"] ?? r["PO Num"] ?? "").trim(),
    });
  }
  return out;
}

/* ---------------- RM INDEX ---------------- */

export function downloadRmTemplate(rm?: RmIndex) {
  const header = ["Alloy / Grade", ...QUARTERS];
  const body = RM_ROWS.map((a) => [a, ...QUARTERS.map((q) => rm?.[a]?.[q] ?? "")]);
  const ws = XLSX.utils.aoa_to_sheet([header, ...body]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "RM Index");
  saveBlob(rm ? "rm-index.xlsx" : "rm-index-template.xlsx",
    XLSX.write(wb, { type: "array", bookType: "xlsx" }));
}

export async function parseRmExcel(file: File): Promise<RmIndex> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const aoa = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "" });
  if (!aoa.length) return {};
  const headerRow = aoa[0] as string[];
  const quarters = headerRow.slice(1).map((q) => String(q).trim());
  const out: RmIndex = {};
  for (let i = 1; i < aoa.length; i++) {
    const row = aoa[i] as unknown[];
    const alloy = String(row[0] ?? "").trim();
    if (!alloy) continue;
    out[alloy] = out[alloy] ?? {};
    quarters.forEach((q, idx) => {
      const v = row[idx + 1];
      if (v === "" || v == null) return;
      const n = Number(v);
      if (!Number.isNaN(n)) out[alloy][q] = n;
    });
  }
  return out;
}

/* ---------------- HISTORY ---------------- */

export function downloadHistoryExport(
  parts: Part[],
  history: Record<string, Record<string, number | null>>,
) {
  const header = ["CC","PO Num","Vendor Code","Part Number","Description","Plant","Alloy", ...QUARTERS];
  const wb = XLSX.utils.book_new();

  const sortedAll = parts.slice().sort((a,b) =>
    vKey(a.vendorCode).localeCompare(vKey(b.vendorCode)) ||
    (a.poNum ?? "").localeCompare(b.poNum ?? "") ||
    (a.plant ?? "").localeCompare(b.plant ?? "") ||
    (a.partNumber ?? "").localeCompare(b.partNumber ?? "")
  );
  const bodyAll = sortedAll.map((p) => [
    cc(p), p.poNum ?? "", p.vendorCode ?? "", p.partNumber, p.description, p.plant, p.alloy,
    ...QUARTERS.map((q) => history[p.id]?.[q] ?? ""),
  ]);
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([header, ...bodyAll]), "All Vendors");

  for (const [vendor, items] of groupByVendor(parts)) {
    const sorted = items.slice().sort((a,b)=>
      (a.poNum ?? "").localeCompare(b.poNum ?? "") ||
      (a.plant ?? "").localeCompare(b.plant ?? "") ||
      (a.partNumber ?? "").localeCompare(b.partNumber ?? "")
    );
    const body = sorted.map((p) => [
      cc(p), p.poNum ?? "", p.vendorCode ?? "", p.partNumber, p.description, p.plant, p.alloy,
      ...QUARTERS.map((q) => history[p.id]?.[q] ?? ""),
    ]);
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([header, ...body]),
      sanitizeSheet(`V_${vendor}`));
  }

  saveBlob("price-history.xlsx", XLSX.write(wb, { type: "array", bookType: "xlsx" }));
}

/* ---------------- FINANCE-GRADE CALC EXPORT ---------------- */

export function downloadCalcExport(
  parts: Part[],
  rows: CalcRow[],
  rm: RmIndex,
  prevQ: string, newQ: string,
  header: { amendmentReason: string },
) {
  const wb = XLSX.utils.book_new();

  // Sheet 1 — Amendment cover
  const cover = XLSX.utils.aoa_to_sheet([
    ["AMENDMENT — Quarterly Price Recompute"],
    [],
    ["Reason", header.amendmentReason],
    ["From Quarter", prevQ],
    ["To Quarter", newQ],
    ["Parts in scope", parts.length],
    ["Generated", new Date().toISOString()],
  ]);
  XLSX.utils.book_append_sheet(wb, cover, "Amendment");

  // Sheet 2 — Calculated Prices (All)
  const calcHeader = [
    "CC","PO Num","Vendor Code","Part #","Description","Plant","Alloy",
    "Cast Wt","Mach Wt","Scrap Wt","AS CAST",
    `Old Price (${prevQ})`,"Prev RM","New RM","Melting Loss",
    "Eff Scrap Wt","Prev Scrap","SCM14 Prev","RM Impact","Scrap Deduction",
    `New Price (${newQ})`,"Δ ₹","Δ %","Note",
  ];
  const calcRow = (r: CalcRow) => {
    const old = r.oldPrice ?? null;
    const delta = old != null && r.newPrice != null ? +(r.newPrice - old).toFixed(2) : null;
    const pct = old && r.newPrice != null ? +(((r.newPrice - old) / old) * 100).toFixed(2) : null;
    return [
      cc(r.part), r.part.poNum ?? "", r.part.vendorCode ?? "",
      r.part.partNumber, r.part.description, r.part.plant, r.part.alloy,
      r.part.castWt, r.part.machiningWt, r.scrapWt, r.part.asCast ? "Y" : "N",
      old, r.prevBase, r.newBase, r.meltingLoss,
      r.effectiveScrapWt, r.prevScrap, r.scm14Prev, r.rmImpact, r.scrapDeduction,
      r.newPrice, delta, pct, r.note ?? "",
    ];
  };
  XLSX.utils.book_append_sheet(wb,
    XLSX.utils.aoa_to_sheet([calcHeader, ...rows.map(calcRow)]),
    "Calculated Prices");

  // Per-vendor calc sheets
  const rowsByVendor = new Map<string, CalcRow[]>();
  for (const r of rows) {
    const k = vKey(r.part.vendorCode);
    const arr = rowsByVendor.get(k) ?? []; arr.push(r); rowsByVendor.set(k, arr);
  }
  for (const [vendor, vrows] of [...rowsByVendor.entries()].sort(([a],[b])=>a.localeCompare(b))) {
    XLSX.utils.book_append_sheet(wb,
      XLSX.utils.aoa_to_sheet([calcHeader, ...vrows.map(calcRow)]),
      sanitizeSheet(`Calc_${vendor}`));
  }

  // Sheet 3 — Price Derivation (per part per qtr step)
  const derHeader = [
    "Part #","Description","Plant","Vendor Code","Alloy",
    "From Q","To Q","Old Price","Prev RM","New RM","Melting Loss (Cast×1.06)",
    "Scrap Wt","Prev Scrap","SCM14 Prev","RM Impact = (NewRM−PrevRM)×MeltLoss",
    "Scrap Deduction = (PrevScrap/SCM14Prev)×(ScrapWt×80%)",
    "New Price = Old + RM Impact − Scrap Deduction","Note",
  ];
  const derBody: unknown[][] = [];
  for (const p of parts) {
    const steps = deriveSeries(p, rm);
    for (const s of steps) {
      derBody.push([
        p.partNumber, p.description, p.plant, p.vendorCode ?? "", p.alloy,
        s.fromQ, s.toQ,
        +s.oldPrice.toFixed(2), s.prevBase, s.newBase, s.meltingLoss,
        s.scrapWt, s.prevScrap, s.scm14Prev, s.rmImpact, s.scrapDeduction,
        s.newPrice, s.note ?? "",
      ]);
    }
    if (steps.length) derBody.push([]); // spacer between parts
  }
  const derWs = XLSX.utils.aoa_to_sheet([derHeader, ...derBody]);
  XLSX.utils.book_append_sheet(wb, derWs, "Price Derivation");

  // Sheet 4 — RM Index snapshot
  const rmHeader = ["Alloy / Grade", ...QUARTERS];
  const rmBody = RM_ROWS.map((a) => [a, ...QUARTERS.map((q) => rm[a]?.[q] ?? "")]);
  const rmWs = XLSX.utils.aoa_to_sheet([rmHeader, ...rmBody]);
  XLSX.utils.book_append_sheet(wb, rmWs, "RM Index");

  const file = `price-calc-${prevQ}-to-${newQ}.xlsx`.replace(/'/g, "");
  saveBlob(file, XLSX.write(wb, { type: "array", bookType: "xlsx" }));
}

/** Helper for inline computations (kept for callers that need a quick derived scrap). */
export function quickScrapWt(p: Part) { return derivedScrapWt(p); }

/* ---------------- VENDOR-WISE PRICE DERIVATION EXPORT (formula-driven) ----------------
 * Finance-grade workbook: one sheet per Vendor × Quarter step.
 * All derived prices use live Excel FORMULAS so auditors can trace and tweak.
 * Layout follows the "Q4'21 onwards" reference template (with scrap rates).
 */
export async function downloadDerivationByVendorExport(
  parts: Part[], rm: RmIndex, grnQty: Record<string, number>,
) {
  const wb = new ExcelJS.Workbook();
  wb.creator = "RM Pricing"; wb.created = new Date();

  /* ---- Cover ---- */
  const cover = wb.addWorksheet("Cover", { properties: { tabColor: { argb: "FF1E3A8A" } } });
  cover.columns = [{ width: 28 }, { width: 60 }];
  cover.addRow(["PRICE DERIVATION — Vendor-wise, Quarter-wise"]).font = { bold: true, size: 16, color: { argb: "FF1E3A8A" } };
  cover.addRow([]);
  cover.addRow(["Generated", new Date().toLocaleString()]);
  cover.addRow(["Vendors", new Set(parts.map((p) => vKey(p.vendorCode))).size]);
  cover.addRow(["Parts", parts.length]);
  cover.addRow(["Quarter range", `${parts[0]?.baseQuarter ?? "—"} → ${QUARTERS[QUARTERS.length - 1]}`]);
  cover.addRow([]);
  const note = cover.addRow(["Note", "One sheet per Vendor × target Quarter. All price-derivation columns use live Excel formulas. Inward = GRN Qty entered in app."]);
  note.getCell(2).alignment = { wrapText: true, vertical: "top" };
  cover.getRow(1).height = 24;

  /* ---- Series cache ---- */
  const seriesByPart = new Map<string, ReturnType<typeof deriveSeries>>();
  for (const p of parts) seriesByPart.set(p.id, deriveSeries(p, rm));

  const HEADER_FILL = "FF1E3A8A";
  const HEADER_FONT = "FFFFFFFF";
  const BAND_FILL   = "FFF1F5F9";
  const TOTAL_FILL  = "FFFEF3C7";
  const ERR_COLOR   = "FFB91C1C";

  /* ---- One sheet per Vendor × toQ ---- */
  for (const [vendor, items] of groupByVendor(parts)) {
    // discover all quarter steps for this vendor
    const stepSet = new Set<string>();
    for (const p of items) for (const s of seriesByPart.get(p.id) ?? []) stepSet.add(`${s.fromQ}__${s.toQ}`);
    const steps = [...stepSet].sort((a, b) => QUARTERS.indexOf(a.split("__")[1]) - QUARTERS.indexOf(b.split("__")[1]));

    for (const stepKey of steps) {
      const [fromQ, toQ] = stepKey.split("__");
      const sortedItems = items
        .slice()
        .filter((p) => (seriesByPart.get(p.id) ?? []).some((x) => x.fromQ === fromQ && x.toQ === toQ))
        .sort((a, b) => sortKey(a).localeCompare(sortKey(b)));
      if (!sortedItems.length) continue;

      const ws = wb.addWorksheet(sanitizeSheet(`${vendor}_${toQ}`), {
        properties: { tabColor: { argb: "FF0EA5E9" } },
        views: [{ state: "frozen", ySplit: 3, xSplit: 4 }],
      });

      // Title row
      ws.mergeCells(1, 1, 1, 21);
      const title = ws.getCell(1, 1);
      title.value = `Vendor ${vendor}  •  ${fromQ}  →  ${toQ}  •  RM Price Derivation`;
      title.font = { bold: true, size: 13, color: { argb: "FFFFFFFF" } };
      title.alignment = { vertical: "middle", horizontal: "left", indent: 1 };
      title.fill = { type: "pattern", pattern: "solid", fgColor: { argb: HEADER_FILL } };
      ws.getRow(1).height = 26;

      // Subtitle / Impact summary (formula filled later)
      ws.mergeCells(2, 1, 2, 4);
      ws.getCell(2, 1).value = "Total Quarterly Impact (₹ Lakhs)";
      ws.getCell(2, 1).font = { bold: true };
      ws.getCell(2, 1).alignment = { horizontal: "right", vertical: "middle", indent: 1 };
      ws.getCell(2, 5).font = { bold: true, color: { argb: "FF065F46" } };
      ws.getCell(2, 5).numFmt = "#,##0.00";

      // Header row (row 3)
      const headers = [
        "S.No","CC","Vendor","Part #","Description","Cast Wt","Mach Wt","Plant","Alloy","PO Num",
        "Melt Loss", `Old Price (${fromQ})`, `${fromQ} RM`, `${toQ} RM`, "RM Impact",
        `${fromQ} Scrap`, `${fromQ} SCM14`, "Scrap Ded",
        `New Price (${toQ})`, "GRN Qty", "Impact (₹L)",
      ];
      const headerRow = ws.getRow(3);
      headers.forEach((h, i) => {
        const c = headerRow.getCell(i + 1);
        c.value = h;
        c.font = { bold: true, color: { argb: HEADER_FONT } };
        c.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
        c.fill = { type: "pattern", pattern: "solid", fgColor: { argb: HEADER_FILL } };
        c.border = { top: { style: "thin" }, bottom: { style: "thin" }, left: { style: "thin" }, right: { style: "thin" } };
      });
      headerRow.height = 30;

      // Column widths
      const widths = [6,16,10,14,28,9,9,7,10,14,10,12,10,10,12,10,10,11,13,10,12];
      widths.forEach((w, i) => ws.getColumn(i + 1).width = w);

      // Data rows
      let row = 4;
      const firstRow = row;
      sortedItems.forEach((p, idx) => {
        const s = (seriesByPart.get(p.id) ?? []).find((x) => x.fromQ === fromQ && x.toQ === toQ)!;
        const asCast = isCastFlag(p);
        const r = ws.getRow(row);
        const R = row;

        r.getCell(1).value = idx + 1;
        r.getCell(2).value = { formula: `D${R}&H${R}` };
        r.getCell(3).value = p.vendorCode ?? "";
        r.getCell(4).value = p.partNumber;
        r.getCell(5).value = p.description;
        r.getCell(6).value = p.castWt;
        r.getCell(7).value = p.machiningWt;
        r.getCell(8).value = p.plant;
        r.getCell(9).value = p.alloy;
        r.getCell(10).value = p.poNum ?? "";
        // Melt Loss = Cast Wt × 1.06
        r.getCell(11).value = { formula: `F${R}*1.06` };
        r.getCell(11).numFmt = "0.0000";
        // Old Price (chained value — engine-computed for the starting point of this step)
        r.getCell(12).value = +s.oldPrice.toFixed(4);
        r.getCell(12).numFmt = "#,##0.00";
        // Prev RM / New RM (values from RM index)
        r.getCell(13).value = s.prevBase ?? null;
        r.getCell(14).value = s.newBase ?? null;
        r.getCell(13).numFmt = r.getCell(14).numFmt = "0.00";
        // RM Impact = (New RM − Prev RM) × Melt Loss
        r.getCell(15).value = { formula: `IFERROR((N${R}-M${R})*K${R},0)` };
        r.getCell(15).numFmt = "0.0000;[Red](0.0000)";
        // Prev Scrap / SCM14 Prev
        if (asCast) {
          r.getCell(16).value = "as cast"; r.getCell(17).value = "as cast";
          r.getCell(16).alignment = r.getCell(17).alignment = { horizontal: "center" };
          r.getCell(16).font = r.getCell(17).font = { italic: true, color: { argb: "FF6B7280" } };
        } else {
          r.getCell(16).value = s.prevScrap ?? null;
          r.getCell(17).value = s.scm14Prev ?? null;
          r.getCell(16).numFmt = r.getCell(17).numFmt = "0.00";
        }
        // Scrap Deduction = (PrevScrap / SCM14Prev) × ((Cast − Mach) × 0.8); 0 if as-cast
        if (asCast) {
          r.getCell(18).value = 0;
        } else {
          r.getCell(18).value = { formula: `IFERROR((P${R}/Q${R})*((F${R}-G${R})*0.8),0)` };
        }
        r.getCell(18).numFmt = "0.0000";
        // New Price = Old + RM Impact − Scrap Ded
        r.getCell(19).value = { formula: `ROUND(L${R}+O${R}-R${R},2)` };
        r.getCell(19).numFmt = "#,##0.00";
        r.getCell(19).font = { bold: true };
        // GRN Qty
        r.getCell(20).value = grnQty[p.id] ?? 0;
        r.getCell(20).numFmt = "#,##0";
        // Impact (Lakhs) = (New − Old) × GRN / 100000
        r.getCell(21).value = { formula: `(S${R}-L${R})*T${R}/100000` };
        r.getCell(21).numFmt = "#,##0.0000;[Red](#,##0.0000)";

        // Missing RM highlight
        if (s.prevBase == null || s.newBase == null) {
          for (let c = 13; c <= 19; c++) {
            r.getCell(c).font = { color: { argb: ERR_COLOR }, italic: true };
          }
        }

        // Banded rows
        if (idx % 2 === 1) {
          for (let c = 1; c <= 21; c++) {
            r.getCell(c).fill = { type: "pattern", pattern: "solid", fgColor: { argb: BAND_FILL } };
          }
        }
        // Borders
        for (let c = 1; c <= 21; c++) {
          r.getCell(c).border = {
            top: { style: "hair", color: { argb: "FFCBD5E1" } },
            bottom: { style: "hair", color: { argb: "FFCBD5E1" } },
            left: { style: "hair", color: { argb: "FFCBD5E1" } },
            right: { style: "hair", color: { argb: "FFCBD5E1" } },
          };
        }
        row++;
      });
      const lastRow = row - 1;

      // Totals row
      const tr = ws.getRow(row);
      tr.getCell(1).value = "TOTAL";
      tr.getCell(1).font = { bold: true };
      ws.mergeCells(row, 1, row, 19);
      tr.getCell(1).alignment = { horizontal: "right", indent: 1 };
      tr.getCell(20).value = { formula: `SUM(T${firstRow}:T${lastRow})` };
      tr.getCell(20).numFmt = "#,##0";
      tr.getCell(21).value = { formula: `SUM(U${firstRow}:U${lastRow})` };
      tr.getCell(21).numFmt = "#,##0.0000;[Red](#,##0.0000)";
      for (let c = 1; c <= 21; c++) {
        tr.getCell(c).fill = { type: "pattern", pattern: "solid", fgColor: { argb: TOTAL_FILL } };
        tr.getCell(c).font = { bold: true, ...(tr.getCell(c).font ?? {}) };
        tr.getCell(c).border = { top: { style: "medium" }, bottom: { style: "double" } };
      }

      // Header summary points at totals row
      ws.getCell(2, 5).value = { formula: `U${row}` };

      ws.autoFilter = { from: { row: 3, column: 1 }, to: { row: lastRow, column: 21 } };
    }
  }

  const buf = await wb.xlsx.writeBuffer();
  saveBlob(`price-derivation-vendorwise.xlsx`, buf as ArrayBuffer);
}

function isCastFlag(p: Part): boolean {
  // Mirror engine's isAsCast without importing it (avoid circular).
  const s = String(p.partNumber).trim();
  return s.endsWith("0") || s.endsWith("6") || p.asCast;
}

/* ---------------- GRN IMPACT ---------------- */

export const GRN_HEADERS = [
  "Vendor Code","PO Num","Plant","Part Number","Description","Alloy",
  "Old Price","New Price","Δ ₹","GRN Qty","Impact (Δ × GRN)",
] as const;

/** GRN keyed by part.id — one row per part-master entry (vendor/po/plant/part combo). */
export function downloadGrnTemplate(
  parts: Part[], rows: CalcRow[], grnQty: Record<string, number>,
  prevQ: string, newQ: string,
) {
  const wb = XLSX.utils.book_new();
  const byId = new Map(rows.map((r) => [r.part.id, r]));

  const buildRows = (items: Part[]) => items.map((p) => {
    const r = byId.get(p.id);
    const old = r?.oldPrice ?? null;
    const np = r?.newPrice ?? null;
    const delta = old != null && np != null ? +(np - old).toFixed(2) : "";
    const qty = grnQty[p.id] ?? "";
    const impact = (typeof delta === "number" && typeof qty === "number")
      ? +(delta * qty).toFixed(2) : "";
    return [
      p.vendorCode ?? "", p.poNum ?? "", p.plant, p.partNumber, p.description, p.alloy,
      old ?? "", np ?? "", delta, qty, impact,
    ];
  });

  const sortedAll = parts.slice().sort((a,b) =>
    vKey(a.vendorCode).localeCompare(vKey(b.vendorCode)) || sortKey(a).localeCompare(sortKey(b))
  );
  XLSX.utils.book_append_sheet(wb,
    XLSX.utils.aoa_to_sheet([
      [`GRN Impact — fill column "GRN Qty". Prices = ${prevQ} → ${newQ}.`],
      [...GRN_HEADERS], ...buildRows(sortedAll),
    ]), "All Vendors");

  for (const [vendor, items] of groupByVendor(parts)) {
    const sorted = items.slice().sort((a,b)=> sortKey(a).localeCompare(sortKey(b)));
    XLSX.utils.book_append_sheet(wb,
      XLSX.utils.aoa_to_sheet([[...GRN_HEADERS], ...buildRows(sorted)]),
      sanitizeSheet(`V_${vendor}`));
  }

  saveBlob(`grn-impact-${prevQ}-to-${newQ}.xlsx`.replace(/'/g,""),
    XLSX.write(wb, { type:"array", bookType:"xlsx" }));
}

/** Parse GRN Excel and return a map of partKey → qty. partKey = vendor|po|plant|part. */
export async function parseGrnExcel(file: File): Promise<Record<string, number>> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type:"array" });
  const out: Record<string, number> = {};
  for (const name of wb.SheetNames) {
    const ws = wb.Sheets[name];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
    for (const r of rows) {
      const vendor = String(r["Vendor Code"] ?? "").trim();
      const po = String(r["PO Num"] ?? "").trim();
      const plant = String(r["Plant"] ?? "").trim();
      const pn = String(r["Part Number"] ?? "").trim();
      const qty = Number(r["GRN Qty"] ?? 0);
      if (!pn || !qty) continue;
      out[`${vendor}|${po}|${plant}|${pn}`] = qty;
    }
  }
  return out;
}

export function grnKey(p: Pick<Part,"vendorCode"|"poNum"|"plant"|"partNumber">) {
  return `${(p.vendorCode??"").trim()}|${(p.poNum??"").trim()}|${p.plant}|${p.partNumber}`;
}
