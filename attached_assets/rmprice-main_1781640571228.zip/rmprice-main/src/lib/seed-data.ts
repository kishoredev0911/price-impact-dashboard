import type { Part, RmIndex } from "./pricing";

export const SEED_RM_INDEX: RmIndex = {
  "SCM 14": {"Q4'21":230,"Q1'22":204,"Q2'22":245,"Q3'22":232.28,"Q4'22":207.33,"Q1'23":195.5,"Q2'23":205.87,"Q3'23":215.33,"Q4'23":209.67,"Q1'24":202.33,"Q2'24":208,"Q3'24":224,"Q4'24":226,"Q1'25":219,"Q2'25":218.33,"Q3'25":236.67,"Q4'25":241.33,"Q1'26":239},
  "ADC 12": {"Q4'21":225,"Q1'22":194,"Q2'22":220,"Q3'22":229.28,"Q4'22":204.33,"Q1'23":192.5,"Q2'23":202.87,"Q3'23":207.33,"Q4'23":201.67,"Q1'24":194.33,"Q2'24":200,"Q3'24":216,"Q4'24":218,"Q1'25":211,"Q2'25":210.33,"Q3'25":228.67,"Q4'25":233.33,"Q1'26":231},
  "JED 838": {"Q4'21":225,"Q1'22":205,"Q2'22":208,"Q3'22":212.5,"Q2'24":210,"Q3'24":226,"Q4'24":228,"Q1'25":221,"Q2'25":220.33,"Q3'25":238.67,"Q4'25":243.33,"Q1'26":241},
  "JED 838 1": {"Q4'25":243.33,"Q1'26":241},
  "LM 25": {"Q4'25":250,"Q1'26":248},
  "Mazak": {"Q4'25":260,"Q1'26":258},
  "M3": {"Q4'25":255,"Q1'26":253},
  "M2": {"Q4'25":252,"Q1'26":250},
  "SCRAP": {"Q4'21":150,"Q1'22":129.33,"Q2'22":146.67,"Q3'22":152.85,"Q4'22":136.22,"Q1'23":128.33,"Q2'23":135.25,"Q3'23":138.22,"Q4'23":134.45,"Q1'24":129.55,"Q2'24":133.33,"Q3'24":144,"Q4'24":145.33,"Q1'25":140.67,"Q2'25":140.22,"Q3'25":152.44,"Q4'25":155.55,"Q1'26":154},
};

const raw: Array<Omit<Part, "id" | "asCast" | "machiningWt"> & { scrapWt: number; rule: string }> = [
  { partNumber:"100275560", description:"FLANGE (CASTING)", plant:"1030", alloy:"SCM 14", castWt:0.96, scrapWt:0, basePrice:243.81, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100275561", description:"FLANGE (ANODISING)", plant:"1080", alloy:"SCM 14", castWt:0.96, scrapWt:0.02, basePrice:291.8, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100277021", description:"Cylinder Machining (PDC)", plant:"1020", alloy:"SCM 14", castWt:0.17, scrapWt:0.012, basePrice:85.23, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100279631", description:"Flange (Machined)", plant:"1020", alloy:"SCM 14", castWt:0.715, scrapWt:0.038, basePrice:230.63, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100336760", description:"Top Cover (Casting)", plant:"1080", alloy:"ADC 12", castWt:0.11, scrapWt:0.004, basePrice:45.73, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100339471", description:"Top Cover - Machining", plant:"1030", alloy:"ADC 12", castWt:0.146, scrapWt:0, basePrice:54.53, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100343611", description:"TOP COVER (MACHINING)", plant:"1080", alloy:"ADC 12", castWt:0.178, scrapWt:0.019, basePrice:85.65, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100347280", description:"Top cover", plant:"1080", alloy:"ADC 12", castWt:0.11, scrapWt:0.004, basePrice:46.18, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100632980", description:"Upper Body -Casting", plant:"1020", alloy:"ADC 12", castWt:0.518, scrapWt:0, basePrice:145.88, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100632981", description:"Body Upper Part (PDC)-Voss", plant:"1080", alloy:"ADC 12", castWt:0.518, scrapWt:0.048, basePrice:206.42, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100632983", description:"Upper Body", plant:"1080", alloy:"ADC 12", castWt:0.518, scrapWt:0.048, basePrice:206.42, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100635031", description:"Treadle Mounting Plate", plant:"1080", alloy:"SCM 14", castWt:0.292, scrapWt:0.005, basePrice:115.71, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"102755611", description:"FLANGE (MACHINED)", plant:"1020", alloy:"SCM 14", castWt:0.96, scrapWt:0.02, basePrice:272.51, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"102770211", description:"Air cylinder", plant:"1080", alloy:"SCM 14", castWt:0.17, scrapWt:0.023, basePrice:71.01, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"106350311", description:"Treadle (Machining)", plant:"1080", alloy:"SCM 14", castWt:0.292, scrapWt:0.002, basePrice:99.15, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"9701906284", description:"Piston", plant:"1030", alloy:"ADC 12", castWt:0.124, scrapWt:0.015, basePrice:62.62, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"9739090124", description:"RG2 Top Cover-(Machining)", plant:"1030", alloy:"SCM 14", castWt:0.192, scrapWt:0.019, basePrice:81.31, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"9739090154", description:"RG2 Body", plant:"1030", alloy:"ADC 12", castWt:0.293, scrapWt:0.026, basePrice:124.69, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100136610", description:"Cylinder Head Casting", plant:"1080", alloy:"JED 838", castWt:0.44, scrapWt:0, basePrice:171.78, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100136950", description:"Cylinder Head", plant:"1080", alloy:"JED 838", castWt:0.69, scrapWt:0, basePrice:245, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
  { partNumber:"100275891", description:"Ram Machined", plant:"1020", alloy:"SCM 14", castWt:0.37, scrapWt:0.04, basePrice:185, baseQuarter:"Q4'25", rule:"Scrap allowed" },
  { partNumber:"100341490", description:"Top Cover", plant:"1020", alloy:"ADC 12", castWt:0.05, scrapWt:0, basePrice:38, baseQuarter:"Q4'25", rule:"No Scrap (ends 0/6)" },
];

export const SEED_PARTS: Part[] = raw.map((r, i) => ({
  id: `p${i + 1}`,
  partNumber: r.partNumber,
  description: r.description,
  plant: r.plant,
  vendorCode: "",
  alloy: r.alloy,
  castWt: r.castWt,
  machiningWt: Math.max(+(r.castWt - r.scrapWt).toFixed(4), 0),
  asCast: r.rule.toLowerCase().includes("no scrap"),
  basePrice: r.basePrice,
  baseQuarter: r.baseQuarter,
}));