export const QUARTERS = [
  "Q4'21","Q1'22","Q2'22","Q3'22","Q4'22","Q1'23","Q2'23","Q3'23","Q4'23",
  "Q1'24","Q2'24","Q3'24","Q4'24","Q1'25","Q2'25","Q3'25","Q4'25","Q1'26","Q2'26",
  "Q3'26","Q4'26","Q1'27","Q2'27","Q3'27","Q4'27",
];

export const ALLOYS = ["SCM 14", "ADC 12", "JED 838", "JED 838 1", "LM 25", "Mazak", "M3", "M2"] as const;
export type Alloy = (typeof ALLOYS)[number];

export type RmIndex = Record<string, Record<string, number | null>>;

export interface Part {
  id: string;
  partNumber: string;
  description: string;
  plant: string;
  vendorCode?: string;
  alloy: string;
  castWt: number;
  machiningWt: number;
  asCast: boolean;
  basePrice: number;
  baseQuarter: string;
  poNum?: string;
}

export interface CalcRow {
  part: Part;
  oldPrice: number | null;
  prevBase: number | null;
  newBase: number | null;
  prevScrap: number | null;
  scm14Prev: number | null;
  meltingLoss: number;
  scrapWt: number;
  effectiveScrapWt: number;
  rmImpact: number | null;
  scrapDeduction: number | null;
  newPrice: number | null;
  note?: string;
}

export function endsIn0or6(pn: string) {
  const s = String(pn).trim();
  return s.endsWith("0") || s.endsWith("6");
}
export function cc(p: Pick<Part, "plant" | "partNumber">) {
  return `${p.plant ?? ""}${p.partNumber ?? ""}`;
}
export function isAsCast(p: Part) { return endsIn0or6(p.partNumber) || p.asCast; }
export function isManualAsCast(p: Part) { return p.asCast && !endsIn0or6(p.partNumber); }
export function derivedScrapWt(p: Part): number {
  return Math.max(+(p.castWt - p.machiningWt).toFixed(4), 0);
}
export function effectiveScrapWt(p: Part): number {
  return isAsCast(p) ? 0 : derivedScrapWt(p);
}

function stepCalc(oldPrice: number, p: Part, rm: RmIndex, prevQ: string, newQ: string): CalcRow {
  const prevBase = rm[p.alloy]?.[prevQ] ?? null;
  const newBase = rm[p.alloy]?.[newQ] ?? null;
  const prevScrap = rm["SCRAP"]?.[prevQ] ?? null;
  const scm14Prev = rm["SCM 14"]?.[prevQ] ?? null;

  const meltingLoss = +(p.castWt * 1.06).toFixed(4);
  const scrapWt = derivedScrapWt(p);
  const eScrap = isAsCast(p) ? 0 : scrapWt;

  let rmImpact: number | null = null;
  if (prevBase != null && newBase != null) rmImpact = +((newBase - prevBase) * meltingLoss).toFixed(4);

  // New scrap formula — ALWAYS subtracted (even if negative, which effectively adds).
  let scrapDeduction: number | null = 0;
  if (eScrap > 0 && prevScrap != null && scm14Prev) {
    scrapDeduction = +((prevScrap / scm14Prev) * (eScrap * 0.8)).toFixed(4);
  }

  let newPrice: number | null = null;
  if (rmImpact != null) newPrice = +(oldPrice + rmImpact - (scrapDeduction ?? 0)).toFixed(2);

  const missing: string[] = [];
  if (prevBase == null) missing.push(`${p.alloy} ${prevQ}`);
  if (newBase == null) missing.push(`${p.alloy} ${newQ}`);

  return {
    part: p, oldPrice, prevBase, newBase, prevScrap, scm14Prev,
    meltingLoss, scrapWt, effectiveScrapWt: eScrap,
    rmImpact, scrapDeduction, newPrice,
    note: missing.length ? `Missing RM: ${missing.join(", ")}` : undefined,
  };
}

export function calcPart(p: Part, rm: RmIndex, prevQ: string, newQ: string): CalcRow {
  const baseIdx = QUARTERS.indexOf(p.baseQuarter);
  const prevIdx = QUARTERS.indexOf(prevQ);
  if (baseIdx < 0 || prevIdx < 0) return stepCalc(p.basePrice, p, rm, prevQ, newQ);

  if (prevIdx < baseIdx) {
    const r = stepCalc(p.basePrice, p, rm, prevQ, newQ);
    return { ...r, oldPrice: null, newPrice: null,
      note: `SAP price starts at ${p.baseQuarter}; select prev ≥ ${p.baseQuarter}.` };
  }

  let oldPrice = p.basePrice;
  for (let i = baseIdx + 1; i <= prevIdx; i++) {
    const step = stepCalc(oldPrice, p, rm, QUARTERS[i - 1], QUARTERS[i]);
    if (step.newPrice == null) {
      return { ...step, oldPrice: null, newPrice: null,
        note: step.note ?? "Cannot chain to selected previous quarter (missing RM)." };
    }
    oldPrice = step.newPrice;
  }
  return stepCalc(oldPrice, p, rm, prevQ, newQ);
}

export function calcAll(parts: Part[], rm: RmIndex, prevQ: string, newQ: string): CalcRow[] {
  return parts.map((p) => calcPart(p, rm, prevQ, newQ));
}

export interface DerivStep {
  fromQ: string; toQ: string;
  oldPrice: number;
  prevBase: number | null; newBase: number | null;
  prevScrap: number | null; scm14Prev: number | null;
  meltingLoss: number; scrapWt: number;
  rmImpact: number | null; scrapDeduction: number;
  newPrice: number | null; note?: string;
}

/** Step-by-step derivation from baseQuarter forward, stopping when RM data runs out. */
export function deriveSeries(p: Part, rm: RmIndex): DerivStep[] {
  const out: DerivStep[] = [];
  const baseIdx = QUARTERS.indexOf(p.baseQuarter);
  if (baseIdx < 0) return out;
  let oldPrice = p.basePrice;
  for (let i = baseIdx + 1; i < QUARTERS.length; i++) {
    const r = stepCalc(oldPrice, p, rm, QUARTERS[i - 1], QUARTERS[i]);
    out.push({
      fromQ: QUARTERS[i - 1], toQ: QUARTERS[i],
      oldPrice, prevBase: r.prevBase, newBase: r.newBase,
      prevScrap: r.prevScrap, scm14Prev: r.scm14Prev,
      meltingLoss: r.meltingLoss, scrapWt: r.effectiveScrapWt,
      rmImpact: r.rmImpact, scrapDeduction: r.scrapDeduction ?? 0,
      newPrice: r.newPrice, note: r.note,
    });
    if (r.newPrice == null) break;
    oldPrice = r.newPrice;
  }
  return out;
}

export function computeHistory(p: Part, rm: RmIndex): Record<string, number | null> {
  const out: Record<string, number | null> = {};
  const baseIdx = QUARTERS.indexOf(p.baseQuarter);
  if (baseIdx < 0) return out;
  out[p.baseQuarter] = p.basePrice;
  let cur = p.basePrice;
  for (let i = baseIdx + 1; i < QUARTERS.length; i++) {
    const r = stepCalc(cur, p, rm, QUARTERS[i - 1], QUARTERS[i]);
    out[QUARTERS[i]] = r.newPrice;
    if (r.newPrice == null) break;
    cur = r.newPrice;
  }
  return out;
}

export interface PartInconsistency {
  partNumber: string;
  field: "alloy" | "castWt" | "machiningWt";
  values: Array<{ value: string | number; ids: string[] }>;
}

export function findInconsistencies(parts: Part[]): PartInconsistency[] {
  const groups = new Map<string, Part[]>();
  for (const p of parts) {
    if (!p.partNumber) continue;
    const arr = groups.get(p.partNumber) ?? [];
    arr.push(p); groups.set(p.partNumber, arr);
  }
  const out: PartInconsistency[] = [];
  for (const [pn, arr] of groups) {
    if (arr.length < 2) continue;
    for (const field of ["alloy", "castWt", "machiningWt"] as const) {
      const byVal = new Map<string, string[]>();
      for (const p of arr) {
        const k = String(p[field]);
        const ids = byVal.get(k) ?? []; ids.push(p.id); byVal.set(k, ids);
      }
      if (byVal.size > 1) {
        out.push({
          partNumber: pn, field,
          values: [...byVal.entries()].map(([v, ids]) => ({
            value: field === "alloy" ? v : Number(v), ids,
          })),
        });
      }
    }
  }
  return out;
}

export function inconsistentIds(parts: Part[]): Set<string> {
  const set = new Set<string>();
  for (const inc of findInconsistencies(parts)) {
    for (const v of inc.values) for (const id of v.ids) set.add(id);
  }
  return set;
}

export function toCSV(rows: CalcRow[], prevQ: string, newQ: string): string {
  const header = [
    "CC","PO Num","Vendor Code","Part Number","Description","Plant","Alloy",
    "Cast Wt","Mach Wt","Scrap Wt","AS CAST",
    `Old Price (${prevQ})`,"Prev RM","New RM","Melting Loss","Eff Scrap Wt",
    "Prev Scrap","SCM14 Prev","RM Impact","Scrap Deduction",
    `New Price (${newQ})`,"% Change","Note",
  ];
  const lines = [header.join(",")];
  for (const r of rows) {
    const old = r.oldPrice ?? 0;
    const pct = r.newPrice != null && old
      ? (((r.newPrice - old) / old) * 100).toFixed(2) + "%" : "";
    lines.push([
      cc(r.part), r.part.poNum ?? "", r.part.vendorCode ?? "",
      r.part.partNumber, `"${r.part.description.replace(/"/g, '""')}"`, r.part.plant, r.part.alloy,
      r.part.castWt, r.part.machiningWt, r.scrapWt, r.part.asCast ? "Y" : "N",
      r.oldPrice ?? "", r.prevBase ?? "", r.newBase ?? "",
      r.meltingLoss, r.effectiveScrapWt, r.prevScrap ?? "", r.scm14Prev ?? "",
      r.rmImpact ?? "", r.scrapDeduction ?? "", r.newPrice ?? "", pct, r.note ?? "",
    ].join(","));
  }
  return lines.join("\n");
}
