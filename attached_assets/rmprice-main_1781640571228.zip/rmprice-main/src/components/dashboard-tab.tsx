import { useMemo } from "react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { IndianRupee, TrendingUp, Boxes, AlertTriangle } from "lucide-react";
import { ALLOYS, QUARTERS, type CalcRow, type Part, type RmIndex } from "@/lib/pricing";

const TREND_ALLOYS = ["SCM 14", "ADC 12", "JED 838", "SCRAP"] as const;
const LINE_COLORS: Record<string, string> = {
  "SCM 14": "#6366f1",
  "ADC 12": "#f59e0b",
  "JED 838": "#10b981",
  "SCRAP": "#94a3b8",
};
const PLANT_COLORS = ["#6366f1", "#f59e0b", "#10b981", "#ef4444", "#0ea5e9", "#a855f7"];

const inr = (n: number) =>
  new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(n);

/** Raw value, no thousand separators. */
const plain = (n: number) => `₹${n.toFixed(2)}`;

export function DashboardTab({
  parts, rm, rows, prevQ, newQ,
}: { parts: Part[]; rm: RmIndex; rows: CalcRow[]; prevQ: string; newQ: string }) {
  const totalExposure = useMemo(
    () => parts.reduce((s, p) => s + p.basePrice, 0),
    [parts],
  );
  const quarterImpact = useMemo(
    () => rows.reduce((s, r) => s + (r.newPrice != null ? r.newPrice - r.part.basePrice : 0), 0),
    [rows],
  );
  const highImpact = useMemo(() => {
    let count = 0, total = 0, n = 0;
    for (const r of rows) {
      if (r.newPrice == null || !r.part.basePrice) continue;
      const pct = Math.abs((r.newPrice - r.part.basePrice) / r.part.basePrice);
      total += r.newPrice - r.part.basePrice; n++;
      if (pct >= 0.01) count++;
    }
    return { count, avg: n ? total / n : 0 };
  }, [rows]);

  const trendData = useMemo(
    () =>
      QUARTERS.map((q) => {
        const row: Record<string, number | string | null> = { quarter: q };
        for (const a of TREND_ALLOYS) row[a] = rm[a]?.[q] ?? null;
        return row;
      }),
    [rm],
  );

  const impactByAlloy = useMemo(() => {
    const acc: Record<string, number> = {};
    for (const r of rows) {
      if (r.newPrice == null) continue;
      acc[r.part.alloy] = (acc[r.part.alloy] ?? 0) + (r.newPrice - r.part.basePrice);
    }
    return ALLOYS.filter((a) => acc[a]).map((a) => ({ alloy: a, impact: +acc[a].toFixed(2) }));
  }, [rows]);

  const exposureByPlant = useMemo(() => {
    const acc: Record<string, number> = {};
    for (const p of parts) acc[`Plant ${p.plant}`] = (acc[`Plant ${p.plant}`] ?? 0) + p.basePrice;
    return Object.entries(acc).map(([name, value]) => ({ name, value: +value.toFixed(2) }));
  }, [parts]);

  const topMovers = useMemo(() => {
    return [...rows]
      .filter((r) => r.newPrice != null && r.part.basePrice)
      .map((r) => ({
        r,
        delta: r.newPrice! - r.part.basePrice,
        pct: ((r.newPrice! - r.part.basePrice) / r.part.basePrice) * 100,
      }))
      .sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta))
      .slice(0, 6);
  }, [rows]);

  return (
    <div className="space-y-4">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi icon={<IndianRupee className="size-4" />} tint="bg-indigo-100 text-indigo-700"
          label="Impact" value={plain(totalExposure)} />
        <Kpi icon={<TrendingUp className="size-4" />} tint="bg-emerald-100 text-emerald-700"
          label={`Quarter Impact (${prevQ}→${newQ})`}
          value={`${quarterImpact >= 0 ? "+" : ""}${plain(quarterImpact)}`}
          valueClass={quarterImpact >= 0 ? "text-emerald-600" : "text-red-600"} />
        <Kpi icon={<Boxes className="size-4" />} tint="bg-slate-100 text-slate-700"
          label="Parts in System" value={String(parts.length)} sub="All anchored" />
        <Kpi icon={<AlertTriangle className="size-4" />} tint="bg-amber-100 text-amber-700"
          label="High-Impact Parts (≥1%)" value={String(highImpact.count)}
          sub={`Avg ₹${highImpact.avg.toFixed(2)} / pc`} />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">RM Index Trend</CardTitle>
            <CardDescription>Alloy prices per Kg by quarter</CardDescription>
          </CardHeader>
          <CardContent className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="quarter" tick={{ fontSize: 10 }} interval={2} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                {TREND_ALLOYS.map((a) => (
                  <Line key={a} type="monotone" dataKey={a} stroke={LINE_COLORS[a]}
                    dot={false} strokeWidth={2} connectNulls />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Impact by Alloy</CardTitle>
            <CardDescription>Net ₹ change ({prevQ}→{newQ}) × parts</CardDescription>
          </CardHeader>
          <CardContent className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={impactByAlloy} margin={{ top: 8, right: 12, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="alloy" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: 12 }} formatter={(v: number) => `₹${inr(v)}`} />
                <Bar dataKey="impact" radius={[4, 4, 0, 0]}>
                  {impactByAlloy.map((d, i) => (
                    <Cell key={i} fill={d.impact >= 0 ? "#10b981" : "#ef4444"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Exposure + Top movers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Exposure by Plant</CardTitle>
            <CardDescription>Total ₹ across part master</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={exposureByPlant} dataKey="value" nameKey="name"
                  innerRadius={60} outerRadius={100} paddingAngle={2} label
                >
                  {exposureByPlant.map((_, i) => (
                    <Cell key={i} fill={PLANT_COLORS[i % PLANT_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => `₹${inr(v)}`} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Top Movers</CardTitle>
            <CardDescription>Biggest ₹/pc swing this quarter</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {topMovers.length === 0 && (
              <div className="text-sm text-muted-foreground py-8 text-center">
                No price movement between {prevQ} and {newQ}.
              </div>
            )}
            {topMovers.map(({ r, delta, pct }) => (
              <div key={r.part.id} className="flex items-center justify-between gap-3 py-1.5 border-b last:border-0">
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{r.part.description || r.part.partNumber}</div>
                  <div className="text-xs text-muted-foreground font-mono truncate">
                    {r.part.partNumber} · Plant {r.part.plant} · {r.part.alloy}
                  </div>
                </div>
                <Badge variant="outline" className={
                  delta >= 0
                    ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border-red-200 bg-red-50 text-red-700"
                }>
                  {delta >= 0 ? "+" : ""}{delta.toFixed(2)} ({pct >= 0 ? "+" : ""}{pct.toFixed(1)}%)
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Kpi({
  icon, tint, label, value, sub, valueClass,
}: { icon: React.ReactNode; tint: string; label: string; value: string; sub?: string; valueClass?: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2">
          <div className={`size-7 rounded-md flex items-center justify-center ${tint}`}>{icon}</div>
          <span className="text-xs text-muted-foreground">{label}</span>
        </div>
        <div className={`mt-2 text-2xl font-semibold tabular-nums ${valueClass ?? ""}`}>{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </CardContent>
    </Card>
  );
}